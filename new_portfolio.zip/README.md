# Nagarajan V — Portfolio (React + Vite + Bootstrap 5)

## Run locally
```bash
npm install
npm run dev        # http://localhost:5173
```

## Build for hosting
```bash
npm run build      # output in /dist — upload to Netlify, Vercel, GitHub Pages or any host
npm run preview    # test the production build
```

## Edit content
Everything (name, skills, experience, projects, services) is in **`src/data.js`**.
- Add GitHub: set `github` in `profile`.
- Add a project: drop a screenshot into `public/projects/` (e.g. `29.webp`) and add an entry to `projects`.
- Replace resume: overwrite `public/resume/Nagarajan_Resume.pdf`.
- Change colours: edit the variables at the top of `src/styles/global.css` (`--accent` etc.).

## Contact form
Opens the visitor's email app (no backend needed). To receive messages directly,
replace `handleSubmit` in `src/components/Contact.jsx` with Formspree/EmailJS or your own Node + Express API.
