import { profile } from '../data.js'

export default function Footer() {
  return (
    <footer className="site-footer">
      <div className="container d-flex flex-column flex-md-row justify-content-between align-items-center gap-3">
        <span>© {new Date().getFullYear()} {profile.short}. Built with React, Vite & Bootstrap.</span>
        <a href="#home" className="back-top">
          Back to top <i className="bi bi-arrow-up ms-1" />
        </a>
      </div>
    </footer>
  )
}
