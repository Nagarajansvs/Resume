import SectionHeading from './SectionHeading.jsx'
import { skillGroups } from '../data.js'

const levelClass = { Advanced: 'lvl-adv', Intermediate: 'lvl-mid', Basic: 'lvl-basic' }

export default function Skills() {
  return (
    <section id="skills" className="section section-alt">
      <div className="container">
        <SectionHeading
          center
          eyebrow="Skills"
          title="My toolkit"
          text="Strong on the frontend, growing on the backend — here’s an honest look at where I am today."
        />

        <div className="level-legend reveal">
          <span><i className="lvl-dot lvl-adv" /> Advanced</span>
          <span><i className="lvl-dot lvl-mid" /> Intermediate</span>
          <span><i className="lvl-dot lvl-basic" /> Basic / Learning</span>
        </div>

        <div className="row g-4">
          {skillGroups.map((g, idx) => (
            <div className="col-lg-4" key={g.title}>
              <div className={`skill-card reveal reveal-delay-${idx}`}>
                <div className="skill-card-head">
                  <span className="icon-box">
                    <i className={`bi ${g.icon}`} />
                  </span>
                  <h3>{g.title}</h3>
                </div>
                <ul className="skill-list">
                  {g.skills.map((s) => (
                    <li key={s.name}>
                      <span>{s.name}</span>
                      <span className={`lvl-badge ${levelClass[s.level]}`}>{s.level}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
