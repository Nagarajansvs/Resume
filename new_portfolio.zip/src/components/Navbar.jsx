import { useEffect, useState } from 'react'
import { profile, asset } from '../data.js'

const links = [
  { id: 'about', label: 'About' },
  { id: 'skills', label: 'Skills' },
  { id: 'experience', label: 'Experience' },
  { id: 'projects', label: 'Projects' },
  { id: 'contact', label: 'Contact' },
]

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)
  const [active, setActive] = useState('')

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  // Scroll-spy: highlight the section in view
  useEffect(() => {
    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && setActive(e.target.id)),
      { rootMargin: '-45% 0px -50% 0px' }
    )
    ;['home', ...links.map((l) => l.id)].forEach((id) => {
      const el = document.getElementById(id)
      if (el) io.observe(el)
    })
    return () => io.disconnect()
  }, [])

  return (
    <header className={`site-nav ${scrolled ? 'is-scrolled' : ''} ${open ? 'is-open' : ''}`}>
      <nav className="container d-flex align-items-center justify-content-between">
        <a href="#home" className="brand" onClick={() => setOpen(false)}>
          <span className="brand-mark">NV</span>
          <span className="brand-name">{profile.short}</span>
        </a>

        <ul className="nav-links">
          {links.map((l) => (
            <li key={l.id}>
              <a
                href={`#${l.id}`}
                className={active === l.id ? 'active' : ''}
                onClick={() => setOpen(false)}
              >
                {l.label}
              </a>
            </li>
          ))}
          <li className="d-lg-none mt-2">
            <a href={asset(profile.resume)} className="btn btn-dark-pill w-100" download>
              <i className="bi bi-download me-2" />
              Resume
            </a>
          </li>
        </ul>

        <div className="d-flex align-items-center gap-2">
          <a href={asset(profile.resume)} className="btn btn-dark-pill d-none d-lg-inline-flex" download>
            <i className="bi bi-download me-2" />
            Resume
          </a>
          <button
            className="nav-toggle d-lg-none"
            aria-label="Toggle menu"
            aria-expanded={open}
            onClick={() => setOpen((o) => !o)}
          >
            <i className={`bi ${open ? 'bi-x-lg' : 'bi-list'}`} />
          </button>
        </div>
      </nav>
    </header>
  )
}
