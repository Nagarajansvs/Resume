import SectionHeading from './SectionHeading.jsx'
import { profile, about, education } from '../data.js'

const facts = [
  { icon: 'bi-person', label: 'Name', value: `${profile.firstName} ${profile.lastName}` },
  { icon: 'bi-geo-alt', label: 'Location', value: profile.location },
  { icon: 'bi-translate', label: 'Languages', value: profile.languages },
  { icon: 'bi-briefcase', label: 'Freelance', value: profile.freelance },
]

export default function About() {
  return (
    <section id="about" className="section">
      <div className="container">
        <div className="row g-5">
          <div className="col-lg-5">
            <SectionHeading eyebrow="About me" title="From pixel-perfect pages to full stack apps." />
          </div>

          <div className="col-lg-7">
            <div className="reveal">
              {about.map((p, i) => (
                <p key={i} className="lead-text">
                  {p}
                </p>
              ))}
            </div>

            <div className="row g-3 mt-2 reveal">
              {facts.map((f) => (
                <div className="col-sm-6" key={f.label}>
                  <div className="fact">
                    <i className={`bi ${f.icon}`} />
                    <div>
                      <small>{f.label}</small>
                      <span>{f.value}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <h3 className="sub-title mt-5 reveal">
              <i className="bi bi-mortarboard me-2" /> Education
            </h3>
            <div className="row g-3 reveal">
              {education.map((e) => (
                <div className="col-md-6" key={e.degree}>
                  <div className="card-soft h-100">
                    <span className="mono-label">{e.years}</span>
                    <h4 className="card-title-sm mt-2">{e.degree}</h4>
                    <p className="text-muted-soft mb-0">{e.school}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
