export default function SectionHeading({ eyebrow, title, text, center = false }) {
  return (
    <div className={`section-heading reveal ${center ? 'text-center mx-auto' : ''}`}>
      <span className="eyebrow">{eyebrow}</span>
      <h2>{title}</h2>
      {text && <p>{text}</p>}
    </div>
  )
}
