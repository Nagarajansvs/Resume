import SectionHeading from './SectionHeading.jsx'
import { services } from '../data.js'

export default function Services() {
  return (
    <section id="services" className="section">
      <div className="container">
        <SectionHeading center eyebrow="What I do" title="How I can help" />
        <div className="row g-4">
          {services.map((s, i) => (
            <div className="col-md-6 col-lg-3" key={s.title}>
              <div className={`service-card reveal reveal-delay-${i % 3}`}>
                <span className="icon-box icon-box--lg">
                  <i className={`bi ${s.icon}`} />
                </span>
                <h3>{s.title}</h3>
                <p>{s.text}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
