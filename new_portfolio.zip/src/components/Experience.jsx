import SectionHeading from './SectionHeading.jsx'
import { experience } from '../data.js'

export default function Experience() {
  return (
    <section id="experience" className="section">
      <div className="container">
        <div className="row g-5">
          <div className="col-lg-4">
            <div className="sticky-lg">
              <SectionHeading
                eyebrow="Experience"
                title="Where I’ve worked"
                text="10+ years with product companies and agencies in Chennai — crypto, NFT, real estate, education and marketing."
              />
            </div>
          </div>

          <div className="col-lg-8">
            <ol className="timeline">
              {experience.map((job) => (
                <li className="timeline-item reveal" key={job.company + job.period}>
                  <div className="timeline-dot" />
                  <div className="timeline-card">
                    <div className="d-flex flex-wrap justify-content-between gap-2 align-items-start">
                      <div>
                        <h3 className="card-title-md">{job.role}</h3>
                        <p className="company">
                          {job.company} <span>· {job.place}</span>
                        </p>
                      </div>
                      <span className="mono-label period">{job.period}</span>
                    </div>
                    <ul className="job-points">
                      {job.points.map((p) => (
                        <li key={p}>{p}</li>
                      ))}
                    </ul>
                    <div className="d-flex flex-wrap gap-2">
                      {job.tags.map((t) => (
                        <span className="chip" key={t}>{t}</span>
                      ))}
                    </div>
                  </div>
                </li>
              ))}
            </ol>
          </div>
        </div>
      </div>
    </section>
  )
}
