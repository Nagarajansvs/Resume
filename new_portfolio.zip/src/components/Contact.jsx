import { useState } from 'react'
import { profile } from '../data.js'

// No backend needed: the form opens the visitor's email app with the
// message pre-filled. To receive messages directly instead, swap
// handleSubmit for a service like Formspree / EmailJS, or your own
// Node.js + Express endpoint.
export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', message: '' })
  const [sent, setSent] = useState(false)

  const update = (e) => setForm({ ...form, [e.target.name]: e.target.value })

  const handleSubmit = (e) => {
    e.preventDefault()
    const subject = encodeURIComponent(`Portfolio enquiry from ${form.name}`)
    const body = encodeURIComponent(`${form.message}\n\n— ${form.name} (${form.email})`)
    window.location.href = `mailto:${profile.email}?subject=${subject}&body=${body}`
    setSent(true)
  }

  return (
    <section id="contact" className="section">
      <div className="container">
        <div className="contact-panel reveal">
          <div className="row g-5">
            <div className="col-lg-5">
              <span className="eyebrow eyebrow--light">Contact</span>
              <h2 className="contact-title">Let’s build something together.</h2>
              <p className="contact-text">
                I’m open to full-time roles, freelance projects and collaborations. Drop a message —
                I usually reply within a day.
              </p>

              <div className="contact-links">
                <a href={`mailto:${profile.email}`}>
                  <i className="bi bi-envelope" />
                  <span>
                    <small>Email</small>
                    {profile.email}
                  </span>
                </a>
                <a href={`tel:${profile.phoneRaw}`}>
                  <i className="bi bi-telephone" />
                  <span>
                    <small>Phone</small>
                    {profile.phone}
                  </span>
                </a>
                <a href={profile.linkedin} target="_blank" rel="noreferrer">
                  <i className="bi bi-linkedin" />
                  <span>
                    <small>LinkedIn</small>
                    nagarajan-v
                  </span>
                </a>
              </div>
            </div>

            <div className="col-lg-7">
              <form className="contact-form" onSubmit={handleSubmit}>
                <div className="row g-3">
                  <div className="col-md-6">
                    <label htmlFor="name" className="form-label">Your name</label>
                    <input id="name" name="name" className="form-control" required value={form.name} onChange={update} />
                  </div>
                  <div className="col-md-6">
                    <label htmlFor="email" className="form-label">Email</label>
                    <input id="email" name="email" type="email" className="form-control" required value={form.email} onChange={update} />
                  </div>
                  <div className="col-12">
                    <label htmlFor="message" className="form-label">Message</label>
                    <textarea id="message" name="message" rows="5" className="form-control" required value={form.message} onChange={update} />
                  </div>
                  <div className="col-12 d-flex flex-wrap align-items-center gap-3">
                    <button type="submit" className="btn btn-accent btn-lg-pill">
                      Send message <i className="bi bi-send ms-2" />
                    </button>
                    {sent && (
                      <small className="form-note">
                        <i className="bi bi-check-circle me-1" /> Your email app should open now.
                      </small>
                    )}
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
