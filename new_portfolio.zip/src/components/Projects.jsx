import { useMemo, useState } from 'react'
import SectionHeading from './SectionHeading.jsx'
import { projects, asset } from '../data.js'

const filters = ['All', 'React', 'HTML', 'WordPress']
const PAGE = 9

export default function Projects() {
  const [filter, setFilter] = useState('All')
  const [limit, setLimit] = useState(PAGE)

  const list = useMemo(
    () => (filter === 'All' ? projects : projects.filter((p) => p.category === filter)),
    [filter]
  )
  const shown = list.slice(0, limit)

  const choose = (f) => {
    setFilter(f)
    setLimit(PAGE)
  }

  return (
    <section id="projects" className="section section-alt">
      <div className="container">
        <div className="d-flex flex-wrap justify-content-between align-items-end gap-4 mb-5">
          <SectionHeading
            eyebrow="Portfolio"
            title="Selected projects"
            text="Live websites I’ve built and shipped. Hover a card to scroll the page preview."
          />
          <div className="filter-tabs reveal" role="tablist">
            {filters.map((f) => (
              <button
                key={f}
                role="tab"
                aria-selected={filter === f}
                className={filter === f ? 'active' : ''}
                onClick={() => choose(f)}
              >
                {f}
                <span className="count">
                  {f === 'All' ? projects.length : projects.filter((p) => p.category === f).length}
                </span>
              </button>
            ))}
          </div>
        </div>

        <div className="row g-4">
          {shown.map((p) => (
            <div className="col-md-6 col-lg-4 fade-in" key={p.title}>
              <a href={p.url} target="_blank" rel="noreferrer" className="project-card">
                <div className="project-shot">
                  <img
                    src={asset(`projects/${p.img}.webp`)}
                    alt={`${p.title} website screenshot`}
                    loading="lazy"
                  />
                  <span className="project-cat">{p.category}</span>
                </div>
                <div className="project-body">
                  <div>
                    <h3>{p.title}</h3>
                    <span>{p.type}</span>
                  </div>
                  <span className="project-arrow">
                    <i className="bi bi-arrow-up-right" />
                  </span>
                </div>
              </a>
            </div>
          ))}
        </div>

        {limit < list.length && (
          <div className="text-center mt-5">
            <button className="btn btn-outline-pill btn-lg-pill" onClick={() => setLimit((l) => l + PAGE)}>
              Load more projects <i className="bi bi-chevron-down ms-2" />
            </button>
          </div>
        )}
      </div>
    </section>
  )
}
