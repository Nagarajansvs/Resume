import { useEffect, useState } from 'react'
import { profile, stats, asset } from '../data.js'

function useTyped(words, speed = 85, pause = 1600) {
  const [text, setText] = useState('')
  const [i, setI] = useState(0)
  const [deleting, setDeleting] = useState(false)

  useEffect(() => {
    const word = words[i % words.length]
    let t
    if (!deleting && text === word) t = setTimeout(() => setDeleting(true), pause)
    else if (deleting && text === '') {
      setDeleting(false)
      setI((n) => n + 1)
    } else {
      t = setTimeout(
        () => setText(word.slice(0, text.length + (deleting ? -1 : 1))),
        deleting ? speed / 2 : speed
      )
    }
    return () => clearTimeout(t)
  }, [text, deleting, i, words, speed, pause])

  return text
}

export default function Hero() {
  const typed = useTyped(profile.typedWords)

  return (
    <section id="home" className="hero">
      <div className="hero-grid-bg" aria-hidden="true" />
      <div className="container position-relative">
        <div className="row align-items-center g-5">
          <div className="col-lg-7 reveal">
            <span className="status-pill">
              <span className="dot" /> Open to new opportunities
            </span>

            <h1 className="hero-title">
              Hi, I’m {profile.firstName}.
              <span className="d-block text-muted-strong">{profile.role}</span>
            </h1>

            <p className="hero-typed">
              I build <span className="typed">{typed}</span>
              <span className="caret" aria-hidden="true" />
            </p>

            <p className="hero-lead">{profile.intro}</p>

            <div className="d-flex flex-wrap gap-3 mt-4">
              <a href="#projects" className="btn btn-accent btn-lg-pill">
                View my work <i className="bi bi-arrow-right ms-2" />
              </a>
              <a href={asset(profile.resume)} className="btn btn-outline-pill btn-lg-pill" download>
                <i className="bi bi-download me-2" /> Download CV
              </a>
            </div>

            <div className="hero-social">
              <a href={profile.linkedin} target="_blank" rel="noreferrer" aria-label="LinkedIn">
                <i className="bi bi-linkedin" />
              </a>
              {profile.github && (
                <a href={profile.github} target="_blank" rel="noreferrer" aria-label="GitHub">
                  <i className="bi bi-github" />
                </a>
              )}
              <a href={`mailto:${profile.email}`} aria-label="Email">
                <i className="bi bi-envelope" />
              </a>
              <span className="hero-location">
                <i className="bi bi-geo-alt me-1" /> {profile.location}
              </span>
            </div>
          </div>

          <div className="col-lg-5 reveal reveal-delay-1">
            <div className="hero-visual">
              <div className="hero-photo">
                <img src={asset(profile.photo)} alt={profile.short} width="440" height="440" />
              </div>
              <div className="float-card float-card--code">
                <span className="code-dot" />
                <span className="code-dot" />
                <span className="code-dot" />
                <pre>
                  <code>
                    <span className="tok-k">const</span> stack = [<br />
                    {'  '}<span className="tok-s">'React'</span>, <span className="tok-s">'Node'</span>,<br />
                    {'  '}<span className="tok-s">'Express'</span>, <span className="tok-s">'MongoDB'</span><br />
                    ]
                  </code>
                </pre>
              </div>
              <div className="float-card float-card--exp">
                <strong>10+</strong>
                <span>years on the web</span>
              </div>
            </div>
          </div>
        </div>

        <div className="hero-stats reveal">
          {stats.map((s) => (
            <div key={s.label} className="hero-stat">
              <strong>{s.value}</strong>
              <span>{s.label}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
