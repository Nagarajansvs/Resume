// ─────────────────────────────────────────────────────────────
//  All portfolio content lives here. Edit this file to update
//  the site — no need to touch the components.
// ─────────────────────────────────────────────────────────────

export const asset = (path) => `${import.meta.env.BASE_URL}${path}`

export const profile = {
  firstName: 'Nagarajan',
  lastName: 'Venkatesan',
  short: 'Nagarajan V',
  role: 'Full Stack Developer',
  location: 'Chennai, Tamil Nadu',
  email: 'nagarajansvs@gmail.com',
  phone: '+91 90473 43441',
  phoneRaw: '+919047343441',
  linkedin: 'https://www.linkedin.com/in/nagarajan-v-685594a0',
  github: '', // add your GitHub URL here, e.g. 'https://github.com/yourname'
  languages: 'Tamil, English',
  freelance: 'Available',
  resume: 'resume/Nagarajan_Resume.pdf',
  photo: 'profile.webp',
  typedWords: ['React interfaces', 'responsive websites', 'Node.js APIs', 'clean user experiences'],
  intro:
    'I build fast, responsive and user-friendly web applications with React — and I’m growing into the full stack with Node.js and databases.',
}

export const stats = [
  { value: '10+', label: 'Years building for the web' },
  { value: '100+', label: 'Websites delivered' },
  { value: '28', label: 'Live projects showcased' },
]

export const about = [
  'I started my career turning designs into pixel-perfect, responsive web pages. Over the last decade I’ve shipped marketing sites, crypto exchanges, NFT marketplaces, admin panels and 100+ email templates for product teams in Chennai.',
  'Today I work as a Full Stack Developer at the beginner level: I’m comfortable building React applications (intermediate), and I’m actively strengthening my backend skills with Node.js, Express and databases. My design background means the interfaces I build look right and feel right.',
]

export const education = [
  {
    years: '2010 – 2012',
    degree: 'Master of Computer Applications (MCA)',
    school: 'A.V.V.M. Sri Pushpam College, Thanjavur',
  },
  {
    years: '2007 – 2010',
    degree: 'Bachelor of Computer Science',
    school: 'Nethaji Subash Chandra Bose Arts & Science College, Thiruvarur',
  },
]

// level: 'Advanced' | 'Intermediate' | 'Basic'
export const skillGroups = [
  {
    title: 'Frontend',
    icon: 'bi-window-stack',
    skills: [
      { name: 'HTML5', level: 'Advanced' },
      { name: 'CSS3 / Sass', level: 'Advanced' },
      { name: 'Bootstrap 5', level: 'Advanced' },
      { name: 'Responsive Design', level: 'Advanced' },
      { name: 'JavaScript (ES6+)', level: 'Intermediate' },
      { name: 'React', level: 'Intermediate' },
      { name: 'TypeScript', level: 'Basic' },
      { name: 'Tailwind CSS', level: 'Intermediate' },
    ],
  },
  {
    title: 'Backend & Database',
    icon: 'bi-hdd-stack',
    skills: [
      { name: 'Node.js', level: 'Basic' },
      { name: 'Express.js', level: 'Basic' },
      { name: 'REST APIs', level: 'Basic' },
      { name: 'MongoDB', level: 'Basic' },
      { name: 'MySQL', level: 'Basic' },
      { name: 'PHP / Laravel', level: 'Basic' },
    ],
  },
  {
    title: 'Tools & Design',
    icon: 'bi-tools',
    skills: [
      { name: 'Git & GitHub', level: 'Intermediate' },
      { name: 'Vite / npm', level: 'Intermediate' },
      { name: 'Figma', level: 'Intermediate' },
      { name: 'Adobe XD', level: 'Intermediate' },
      { name: 'Photoshop', level: 'Intermediate' },
      { name: 'WordPress', level: 'Intermediate' },
    ],
  },
]

export const experience = [
  {
    role: 'Web Designer & Front-End Developer',
    company: 'Akk Line Media',
    place: 'Chennai',
    period: 'Aug 2023 – Present',
    points: [
      'Build React and TypeScript websites from Figma / XD designs.',
      'Convert PSD, Figma and XD layouts into responsive, production-ready pages.',
      'Work closely with business analysts to turn requirements into UI.',
      'Deliver marketing websites for multiple clients.',
    ],
    tags: ['React', 'TypeScript', 'Figma'],
  },
  {
    role: 'Web Designer',
    company: 'Guardianlink (Appstar Applications Pvt Ltd)',
    place: 'Chennai',
    period: 'Jun 2019 – Jul 2023',
    points: [
      'Built UI for crypto exchange websites, user panels and admin panels.',
      'Developed NFT marketplace and landing websites (Jump.trade, Beyondlife).',
      'Created 50+ marketing email templates.',
    ],
    tags: ['React', 'Web3 UI', 'Email'],
  },
  {
    role: 'Web Designer',
    company: 'JustSee Info Service Pvt Ltd',
    place: 'Chennai',
    period: 'Jan 2017 – Jun 2019',
    points: [
      'Created 100+ websites and 50+ marketing email templates.',
      'Worked on content management systems and marketing websites.',
      'Designed logos, brochures and banners.',
    ],
    tags: ['HTML/CSS', 'CMS', 'Branding'],
  },
  {
    role: 'Web Designer',
    company: 'IndiaProperty Online Pvt Ltd',
    place: 'Chennai',
    period: 'Apr 2014 – Jun 2016',
    points: [
      'Created 50+ websites and 50+ email templates and signatures.',
      'Converted PSD layouts into responsive HTML pages.',
    ],
    tags: ['HTML/CSS', 'Responsive'],
  },
  {
    role: 'XML Operator',
    company: 'Amnet Systems Pvt Ltd',
    place: 'Chennai',
    period: 'Apr 2012 – May 2013',
    points: ['Built 25+ websites and helped clients make them user-friendly.'],
    tags: ['XML', 'HTML'],
  },
]

// category: 'React' | 'HTML' | 'WordPress'
export const projects = [
  { title: 'Jump.trade', url: 'https://www.jump.trade/', img: 10, category: 'React', type: 'NFT Marketplace' },
  { title: 'Callit', url: 'https://callit.jump.trade', img: 11, category: 'React', type: 'Web3 Game' },
  { title: 'Worktual', url: 'https://worktual.co.uk', img: 12, category: 'React', type: 'SaaS Website' },
  { title: 'Hurley HFT', url: 'https://hurley.jump.trade', img: 13, category: 'React', type: 'NFT Drop' },
  { title: 'Amitabh Beyondlife Club', url: 'https://amitabh.beyondlife.club', img: 14, category: 'React', type: 'NFT Collection' },
  { title: 'Cityplots', url: 'https://www.cityplots.io/', img: 19, category: 'React', type: 'Metaverse' },
  { title: 'Livenscience', url: 'https://livenscience.com/', img: 20, category: 'React', type: 'Corporate' },
  { title: 'Beyondlife', url: 'https://www.beyondlife.club', img: 1, category: 'HTML', type: 'NFT Club' },
  { title: 'Appdupe', url: 'https://www.appdupe.com', img: 2, category: 'HTML', type: 'Agency' },
  { title: 'Polycruz', url: 'https://www.polycruz.io', img: 3, category: 'HTML', type: 'Web3' },
  { title: 'Crypto Currency Exchange', url: 'https://www.cryptocurrencyexchangescript.com', img: 4, category: 'HTML', type: 'Crypto' },
  { title: 'Turnkeytown', url: 'https://www.turnkeytown.com/', img: 5, category: 'HTML', type: 'Agency' },
  { title: 'Blockchain App Factory', url: 'https://www.blockchainappfactory.com/', img: 6, category: 'HTML', type: 'Blockchain' },
  { title: 'Centaurus', url: 'https://thecentaurus.io/', img: 7, category: 'HTML', type: 'Web3' },
  { title: 'Inoru', url: 'https://www.inoru.com/', img: 8, category: 'HTML', type: 'Agency' },
  { title: 'Fully Faltoo NFT', url: 'https://fullyfaltoonft.com/home.php', img: 9, category: 'HTML', type: 'NFT' },
  { title: 'Guardianlink', url: 'https://www.guardianlink.io/', img: 15, category: 'HTML', type: 'Web3 Company' },
  { title: 'BBM Coin', url: 'https://pbm-coin.com', img: 16, category: 'HTML', type: 'Crypto' },
  { title: 'Appstars Applications', url: 'https://www.appstarsapplications.com/', img: 17, category: 'HTML', type: 'Corporate' },
  { title: 'Ashvattha Capital', url: 'https://www.ashvatthacapital.in/', img: 21, category: 'HTML', type: 'Finance' },
  { title: 'Dynamic Solar', url: 'https://dynamicsolar.in', img: 22, category: 'HTML', type: 'Business' },
  { title: 'Excel Prodigy', url: 'https://www.excelprodigy.com', img: 23, category: 'HTML', type: 'Education' },
  { title: 'Mahalashmi Women’s College', url: 'https://mahalashmiwomenscollege.edu.in', img: 24, category: 'HTML', type: 'Education' },
  { title: 'Infinite Block Tech', url: 'https://www.infiniteblocktech.com', img: 25, category: 'HTML', type: 'Blockchain' },
  { title: 'IndiaProperty', url: 'https://www.indiaproperty.com', img: 26, category: 'HTML', type: 'Real Estate' },
  { title: 'Next Gen App Lab', url: 'https://nextgenapplab.com/', img: 28, category: 'HTML', type: 'Agency' },
  { title: 'Eon8', url: 'https://www.eon8.com', img: 18, category: 'WordPress', type: 'Corporate' },
  { title: 'San Academy', url: 'https://www.sanacademy.edu.in', img: 27, category: 'WordPress', type: 'Education' },
]

export const services = [
  {
    icon: 'bi-filetype-jsx',
    title: 'React Development',
    text: 'Component-based React apps with clean state handling, reusable UI and fast Vite builds.',
  },
  {
    icon: 'bi-vector-pen',
    title: 'Design to Code',
    text: 'Figma, XD or PSD designs turned into pixel-perfect, responsive pages that work on every screen.',
  },
  {
    icon: 'bi-diagram-3',
    title: 'Full Stack Basics',
    text: 'Simple REST APIs with Node.js & Express, connected to MongoDB or MySQL for small applications.',
  },
  {
    icon: 'bi-envelope-paper',
    title: 'Landing Pages & Emails',
    text: 'High-converting marketing landing pages and email templates that render well in every inbox.',
  },
]
