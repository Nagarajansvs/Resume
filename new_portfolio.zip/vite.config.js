import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// base: './' → build output works on any host (Netlify, Vercel, GitHub Pages sub-folder)
export default defineConfig({
  plugins: [react()],
  base: './',
})
